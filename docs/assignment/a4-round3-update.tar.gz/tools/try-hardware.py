#!/usr/bin/env python3
"""Add Auction 2's new items to a copy of a practice world, the way the website adds them to the game's worlds.

    python3 tools/try-hardware.py worlds/practice/full.toml worlds/practice/mine.toml --as 1 cache low-latency
    python3 tools/try-hardware.py worlds/practice/full.toml worlds/practice/mine.toml --as 1 shared-cache=2,17

Items (numbers from rules.json `hardware`):
  low-latency       both of the AS's hub-to-access links at low_latency_access.latency_ms
  cache             a content cache on the AS's access switch: cdn_cache.share of the Web and Video its homes get
                    from content reached only through the Tier-1 comes from the cache instead
  shared-cache=B,C  the same cache, also serving the homes of ASes B, C (list the joint-bid partners at the IXP
                    where it sits; the website serves only those)
Give an item twice for two units. Write the output beside the input: the program paths in it are relative to that
folder. The other items are edits by hand (docs/a4-api-guide.md, section 6)."""
import argparse
import json
import math
import os
import re

HEADER = re.compile(r'^\s*\[\[?([A-Za-z0-9_.]+)\]\]?\s*$')


def blocks(text):
    out, cur, lines = [], None, []
    for line in text.splitlines():
        m = HEADER.match(line)
        if m:
            out.append((cur, lines))
            cur, lines = m.group(1), [line]
        else:
            lines.append(line)
    out.append((cur, lines))
    return out


def field(lines, key):
    for line in lines:
        m = re.match(rf'^\s*{key}\s*=\s*(.+?)\s*$', line)
        if m:
            return m.group(1)
    return None


def home_ids(a, cls):
    """AS a's two home sources of one class (Web 1, Video 2), one per town."""
    return [10 * (a - 1) + cls, 10 * (a - 1) + 3 + cls]


def low_latency(text, a, latency_ms):
    us = int(math.floor(latency_ms * 1000 + 0.5))
    pairs = {(10 * a + x, 10 * a + 2 + x) for x in (1, 2)}
    out = []
    for h, lines in blocks(text):
        if h == 'link' and tuple(sorted((int(field(lines, 'a')), int(field(lines, 'b'))))) in pairs:
            lines = [re.sub(r'^(\s*latency_us\s*=\s*)(.+)$', lambda m: f'{m.group(1)}{us}', ln) for ln in lines]
        out.extend(lines)
    return '\n'.join(out) + '\n'


def add_cache(text, a, share, serves=()):
    """share of the Tier-1-only Web and Video to the served homes comes from a cache on switch 10a+3; each
    external source stops sending those homes and a new Tier-1 source sends them the rest. A second cache for the
    same homes takes its share of what is left."""
    served = [a] + [b for b in serves if b != a]
    ids = [int(field(ls, 'id')) for h, ls in blocks(text) if h == 'a4.app']
    nid = max(ids) + 1
    k = sum(1 for h, ls in blocks(text) if h == 'app' and field(ls, 'switch') == str(10 * a + 3)
            and int(field(ls, 'prefix').strip('"').split('.')[2]) >= 64)    # caches already on this AS
    out, moved_by = [], {}
    for h, lines in blocks(text):
        if h == 'a4.app' and (field(lines, 'role') or '').strip('"') == 'external':
            cls = int(field(lines, 'class'))
            to = json.loads(field(lines, 'to'))
            mine = {i for b in served for i in home_ids(b, cls)}
            moved = [i for i in to if i in mine]
            if moved:
                per = float(field(lines, 'rate_mbps')) / len(to)
                keep = [i for i in to if i not in mine]
                lines = [re.sub(r'^(\s*rate_mbps\s*=\s*).*$', lambda m: f'{m.group(1)}{per * len(keep):.6f}', ln)
                         for ln in lines]
                lines = [re.sub(r'^(\s*to\s*=\s*).*$', lambda m: f'{m.group(1)}{json.dumps(keep)}', ln) for ln in lines]
                moved_by[int(field(lines, 'id'))] = (cls, per * len(moved), moved)
        out.extend(lines)
    text = '\n'.join(out) + '\n'
    where = {int(field(ls, 'id')): field(ls, 'switch') for h, ls in blocks(text) if h == 'app'}
    apps, rows = [], []
    for j, (src, (cls, rate, moved)) in enumerate(sorted(moved_by.items())):
        rest, cache = nid + 2 * j, nid + 2 * j + 1
        apps += ['', '[[app]]', f'id = {rest}', f'switch = {where[src]}', f'prefix = "10.{200 + rest // 250}.{rest % 250}.0/24"',
                 '', '[[app]]', f'id = {cache}', f'switch = {10 * a + 3}', f'prefix = "10.{a}.{64 + 4 * k + cls}.0/24"']
        to = json.dumps(moved)
        rows += ['', '[[a4.app]]', f'id = {rest}', f'class = {cls}', f'rate_mbps = {rate * (1 - share):.6f}', f'to = {to}',
                 'role = "external"',
                 '', '[[a4.app]]', f'id = {cache}', f'class = {cls}', f'rate_mbps = {rate * share:.6f}', f'to = {to}',
                 'role = "cache"']
    i = text.index('\n[a4]')
    return text[:i] + '\n' + '\n'.join(apps) + '\n' + text[i:] + '\n'.join(rows) + '\n'


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('world')
    ap.add_argument('out')
    ap.add_argument('--as', dest='a', type=int, required=True, help='your AS id in the practice world')
    ap.add_argument('--rules', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'rules.json'))
    ap.add_argument('items', nargs='+')
    args = ap.parse_args()
    hw = json.load(open(args.rules))['hardware']
    text = open(args.world).read()
    for it in args.items:
        name, _, rest = it.partition('=')
        if name == 'low-latency':
            text = low_latency(text, args.a, hw['low_latency_access']['latency_ms'])
        elif name == 'cache':
            text = add_cache(text, args.a, hw['cdn_cache']['share'])
        elif name == 'shared-cache':
            text = add_cache(text, args.a, hw['shared_cache']['share'], [int(b) for b in rest.split(',') if b])
        else:
            raise SystemExit(f'unknown item {it!r}: low-latency, cache or shared-cache=B,C')
    open(args.out, 'w').write(text)
    print(f'wrote {args.out}')


if __name__ == '__main__':
    main()
