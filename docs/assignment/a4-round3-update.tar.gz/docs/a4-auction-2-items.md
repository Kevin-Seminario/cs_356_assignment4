# Auction 2: the items

Auction 2 opens Monday Nov 16 and closes Wednesday Nov 18 at 20:00 CT. An item you win can be installed from the
next cutoff (Round 4, Thursday Nov 19) and counts in every round after that. The numbers below are in rules.json
(`hardware`); the lots, units and reserves are on the Auctions page.

There is no cap on how many units of a lot one team may win. Each bid is for one unit.

## Links across the ring (microwave, ordinary)

A link from one of your hubs to the IXP on the far side of the ring. It carries traffic only once you have an
agreement with a team there. The link alone does nothing. Microwave is faster (12 ms) and smaller (50 Mb/s);
ordinary is slower (22 ms) and larger (100 Mb/s). A second link goes at your other hub.

Real networks: long-haul links between exchanges, often built by several carriers together as a consortium. Here a
consortium is a joint bid.

## Content cache (new)

A cache on your access switch. A share of the Web and Video your homes get from content reached only through the
Tier-1 is served from the cache instead, so it never crosses the Tier-1 and pays no Tier-1 fee. A second cache on
the same AS serves the same share of what is left. Install it on your AS; there is nothing to configure.

Real networks: content providers place cache servers inside ISPs (Netflix Open Connect, Google Global Cache) because
it cuts the ISP's transit bill.

## Shared cache at an IXP (new, joint)

The same cache, placed at one of your IXPs and sold only to joint bids. It serves the owner's homes and the homes of
every other team in the joint bid that is at that IXP, over the owner's IXP link to them. The joint-bid file says who
pays what, and what the teams pay one another each round after the auction.

Real networks: CDN nodes at exchanges that serve every member peering there.

## Repair crew

Your failed links come back after half the outage. It helps only when failures hit your links, which from Round 3
happen more often and for longer. A second crew adds nothing.

## Low-latency access (new)

Both of your hub-to-access links at 2 ms instead of 6 ms. Every packet to or from your homes gets 4 ms faster each
way, 8 ms on a round trip. That matters most for Calls (80 ms target) and Trading (30 ms).

Real networks: straighter fibre routes and low-latency wavelengths sold to trading firms.

## Joint bids

Any lot can be bought by two to four teams together, and the shared cache only so. A joint bid is an agreement file,
built from `examples/agreements/joint_bid` (in the Round 3 update) and uploaded on the Agreements page like any other.
It says which lot (the term `("bid", "shared_cache", 70)`: the lot's key and the total), each team's share
(`share_1`, `share_2`, ... in party order), and what the teams pay one another after the auction. The first team in the
file owns the item and installs it.

Every team in it signs. At the last signature the auction takes the bid, holding each team's share from its own
credits, so a joint bid can be larger than any one team's credits. If a team lacks its share, or the bid is below the
minimum by then, it is refused and nothing is held. Unsigned when the lot closes, it lapses. If it is outbid, every
team gets its share back; to raise, upload a new file.

If it wins, the file runs every round to the end of the season and cannot be declined, and the item stays where its
owner first installs it; it cannot be moved or sold. Agree the shares and the payment rule before anyone uploads.

## Trying an item before you bid

`tools/try-hardware.py` (in the Round 3 update) adds the cache, the shared cache or low-latency access to a copy of
a practice world, the same way the website adds them to the game's worlds. Run your program in it and compare with
the world without the item. The other items are edits by hand (`docs/a4-api-guide.md`, section 6).
