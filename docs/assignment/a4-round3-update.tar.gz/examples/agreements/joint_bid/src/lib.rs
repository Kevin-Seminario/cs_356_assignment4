//! Joint bid: two to four teams buy one unit of an auction lot together.
//! The term `bid` names the lot (its key as the unit, e.g. "shared_cache",
//! "cdn_cache", "cross_ring.microwave") and the total in credits, and
//! `share_1`, `share_2`, ... are each party's credits, in party order; the
//! shares add up to the total. The first party owns the item and installs it.
//!
//! Upload it on the Agreements page; every party signs. At the last
//! signature the auction takes the bid and holds each share from that
//! party's credits in the world. If it wins, this file runs every round to
//! the end of the season and cannot be declined; the item stays where its
//! owner first installs it. Links stay empty: the file is the bid and what
//! the parties pay one another afterwards.
//!
//! This starter's payment rule: each partner pays the owner `fee` dollars
//! a round for its use of the item. Set `fee` to 0 for no payments, or
//! write any rule you agree on.
use switch_program_sdk::wire::{SettleInput2W, SettleOutputW};

fn settle(input: &SettleInput2W) -> SettleOutputW {
    let mut out = input.out();
    let fee = input.term("fee");               // millionths of a dollar
    for i in 1..input.parties.len() {
        out.pay(i, 0, fee);                     // partner i pays the owner (party 0)
    }
    out
}

// A starter: put your own team codes, world, lot, numbers and words in.
switch_program_sdk::agreement_program! {
    settle: settle,
    world: 1,
    parties: ["AAA", "BBB", "CCC"],
    links: [],
    cap: 20,
    rounds: 3,                 // a joint bid that wins runs to the end of the season whatever this says
    terms: [
        ("bid", "shared_cache", 70),
        ("share_1", "cr", 25),
        ("share_2", "cr", 25),
        ("share_3", "cr", 20),
        ("fee", "$/round", 10),
    ],
    reads: [
        "A joint bid of 70 cr on the shared cache: AAA 25, BBB 25, CCC 20.",
        "AAA owns the cache and installs it; it serves BBB and CCC at its IXP.",
        "BBB and CCC each pay AAA $10 a round while the cache runs.",
    ],
}
